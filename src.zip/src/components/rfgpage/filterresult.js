import '../../style/rfgpage/filterresult.css';

const Func_filterresult_filter_result = () => {
    return (
        <div className="filterresult-form">
            결과 <br/>
            결과<br/>
            결과<br/>
            결과<br/>
            결과<br/>
            
        </div>
    );
}

export default Func_filterresult_filter_result;